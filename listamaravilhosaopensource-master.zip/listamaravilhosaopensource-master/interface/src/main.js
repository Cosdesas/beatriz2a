import React from "react";
import logo from "./img/logo.png";

function Main() {
  return (
    <div>
      <header>
        <img src={logo} alt="logo" />
      </header>
    </div>
  );
}

export default Main;
